GitHub Pages bundle
1) Create a repo (public or private with Pages).
2) Upload index.html, manifest.webmanifest, sw.js, README.md to the repo root (or /docs).
3) Enable GitHub Pages (main branch / root or /docs).
4) Open the Pages URL on your phone.
5) iPhone: Safari → Share → Add to Home Screen. Android: Chrome → Add to Home screen.
